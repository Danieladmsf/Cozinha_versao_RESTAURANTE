from flask import Flask, jsonify, request
from flask_cors import CORS
import psycopg2
from psycopg2.extras import RealDictCursor
import sys

# Redirecionar stdout/stderr para log se necessario
# sys.stdout = open('api_log.txt', 'a')
# sys.stderr = sys.stdout

app = Flask(__name__)
CORS(app)

DB = {"host": "10.110.65.232", "port": "8745", "database": "vr", "user": "postgres", "password": "VrPost@Server"}

@app.route('/')
def home(): return jsonify({"status": "online"})

@app.route('/produto/<codigo>')
def get_produto(codigo):
    try:
        conn = psycopg2.connect(**DB)
        cur = conn.cursor(cursor_factory=RealDictCursor)
        # CORRIGIDO: Busca apenas por ID
        cur.execute(f"SELECT * FROM produto WHERE id = {codigo} LIMIT 1")
        r = cur.fetchone()
        conn.close()
        return jsonify({"found": bool(r), "data": dict(r) if r else None})
    except Exception as e: return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
